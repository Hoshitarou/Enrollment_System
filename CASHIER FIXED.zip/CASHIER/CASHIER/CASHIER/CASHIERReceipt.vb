﻿Public Class CASHIERReceipt

End Class